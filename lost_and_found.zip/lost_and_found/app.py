from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import os
from datetime import datetime

# ─────────────────────────────────────────────
#  App Setup
# ─────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = "lostandfound_secret_123"   # needed for flash messages

DB_PATH = "lost_found.db"


# ─────────────────────────────────────────────
#  Database Helper
# ─────────────────────────────────────────────
def get_db():
    """Open a connection to the SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # lets us access columns by name
    return conn


def init_db():
    """Create the items table if it doesn't already exist."""
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT    NOT NULL,
            description TEXT    NOT NULL,
            category    TEXT    NOT NULL,
            status      TEXT    NOT NULL DEFAULT 'Lost',
            location    TEXT    NOT NULL,
            contact     TEXT    NOT NULL,
            date_posted TEXT    NOT NULL
        )
    """)
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────
#  Routes
# ─────────────────────────────────────────────

# HOME – show all items (with optional search & filter)
@app.route("/")
def index():
    conn = get_db()

    search  = request.args.get("search", "").strip()
    status  = request.args.get("status", "All")
    category = request.args.get("category", "All")

    query  = "SELECT * FROM items WHERE 1=1"
    params = []

    if search:
        query  += " AND (title LIKE ? OR description LIKE ? OR location LIKE ?)"
        params += [f"%{search}%", f"%{search}%", f"%{search}%"]

    if status != "All":
        query  += " AND status = ?"
        params.append(status)

    if category != "All":
        query  += " AND category = ?"
        params.append(category)

    query += " ORDER BY id DESC"

    items = conn.execute(query, params).fetchall()
    conn.close()

    return render_template("index.html",
                           items=items,
                           search=search,
                           selected_status=status,
                           selected_category=category)


# REPORT – show the form to report a lost/found item
@app.route("/report", methods=["GET", "POST"])
def report():
    if request.method == "POST":
        title       = request.form["title"].strip()
        description = request.form["description"].strip()
        category    = request.form["category"]
        status      = request.form["status"]
        location    = request.form["location"].strip()
        contact     = request.form["contact"].strip()
        date_posted = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Basic validation
        if not all([title, description, location, contact]):
            flash("Please fill in all fields.", "error")
            return redirect(url_for("report"))

        conn = get_db()
        conn.execute("""
            INSERT INTO items (title, description, category, status, location, contact, date_posted)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (title, description, category, status, location, contact, date_posted))
        conn.commit()
        conn.close()

        flash("Item reported successfully!", "success")
        return redirect(url_for("index"))

    return render_template("report.html")


# DETAIL – view a single item
@app.route("/item/<int:item_id>")
def item_detail(item_id):
    conn = get_db()
    item = conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
    conn.close()

    if item is None:
        flash("Item not found.", "error")
        return redirect(url_for("index"))

    return render_template("detail.html", item=item)


# EDIT – update an existing item
@app.route("/edit/<int:item_id>", methods=["GET", "POST"])
def edit_item(item_id):
    conn = get_db()
    item = conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()

    if item is None:
        flash("Item not found.", "error")
        return redirect(url_for("index"))

    if request.method == "POST":
        title       = request.form["title"].strip()
        description = request.form["description"].strip()
        category    = request.form["category"]
        status      = request.form["status"]
        location    = request.form["location"].strip()
        contact     = request.form["contact"].strip()

        conn.execute("""
            UPDATE items
            SET title=?, description=?, category=?, status=?, location=?, contact=?
            WHERE id=?
        """, (title, description, category, status, location, contact, item_id))
        conn.commit()
        conn.close()

        flash("Item updated successfully!", "success")
        return redirect(url_for("item_detail", item_id=item_id))

    conn.close()
    return render_template("edit.html", item=item)


# DELETE – remove an item
@app.route("/delete/<int:item_id>", methods=["POST"])
def delete_item(item_id):
    conn = get_db()
    conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()

    flash("Item deleted.", "success")
    return redirect(url_for("index"))


# ─────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    init_db()          # create DB/table on first run
    app.run(debug=True)
