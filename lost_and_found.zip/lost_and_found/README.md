# 📦 Lost & Found Portal

A web application built with **Flask** and **SQLite** that lets students report and track lost or found items on campus.

## 🚀 Features
- Report lost or found items
- Search and filter items by name, status, and category
- View full item details
- Edit or delete any item
- Fully connected to a SQLite database (Insert / Update / Fetch / Delete)

---

## 🛠️ Setup & Run

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/lost-and-found-portal.git
cd lost-and-found-portal
```

### 2. Create a virtual environment
```bash
python -m venv venv
```

Activate it:
- **Windows:** `venv\Scripts\activate`
- **Mac/Linux:** `source venv/bin/activate`

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the app
```bash
python app.py
```

Open your browser and go to: **http://127.0.0.1:5000**

---

## 🗄️ Database

SQLite database (`lost_found.db`) is created automatically on first run.

### Table: `items`

| Column       | Type    | Description                  |
|-------------|---------|------------------------------|
| id          | INTEGER | Auto-increment primary key   |
| title       | TEXT    | Name of the item             |
| description | TEXT    | Description of the item      |
| category    | TEXT    | Electronics, Books, etc.     |
| status      | TEXT    | Lost / Found / Claimed       |
| location    | TEXT    | Where it was lost/found      |
| contact     | TEXT    | Reporter's contact info      |
| date_posted | TEXT    | Timestamp of report          |

---

## 🌐 Routes

| Route              | Method     | Description              |
|-------------------|------------|--------------------------|
| `/`               | GET        | Home – list all items    |
| `/report`         | GET, POST  | Report a new item        |
| `/item/<id>`      | GET        | View item details        |
| `/edit/<id>`      | GET, POST  | Edit an existing item    |
| `/delete/<id>`    | POST       | Delete an item           |

---

## 🧰 Tech Stack
- **Python 3** + **Flask**
- **SQLite** (via Python's built-in `sqlite3`)
- **Jinja2** templating
- Plain **HTML/CSS** (no external JS frameworks)

---

## 👤 Author
**Your Name** – Practical Exam Project
